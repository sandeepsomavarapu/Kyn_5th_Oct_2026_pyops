import csv

csv_file_path = 'data.csv'
with open(csv_file_path, 'w') as file:
    csv_writer = csv.writer(file)
    csv_writer.writerow(['Name', 'Age', 'City'])
    csv_writer.writerow(['Alice', 30, 'New York'])
    csv_writer.writerow(['Bob', 25, 'Los Angeles'])
with open(csv_file_path, 'r') as file:
    csv_reader = csv.reader(file)
    for row in csv_reader:
        print(row)    
file=open("example.txt","a")
# file.write("Hello, this is a new line.\n")
# file.write("This file is new line for demonstrating file I/O operations in Python.\n")
list1=["This is line 1\n","This is line 2\n","This is line 3\n"]
file.writelines(list1)
file.close()

file=open("example.txt","r")
content=file.readlines()
for i in content:
    print(i)
file.close()
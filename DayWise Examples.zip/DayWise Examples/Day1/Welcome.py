print("Welcome to Python!")
name='John'
name1="Jane"
print(type(name))
print(type(name1))
#this program to print welcome message  comments

if name=="sandeep":
    print("Hello Sandeep!")
else:
    print("Hello Guest!")    

marks=int(input("Enter your marks:"))#90  "90"
if marks>=90:
    print("Grade A")
elif marks>=80:
    print("Grade B")
else:
    print("Grade C")

for i in range(1,6):
    print("welcome to python",i)

while marks>0:
    print("Marks are:",marks)
    marks=marks-50    

emps=  ["John","Jane","Sandeep","Ravi","Ramesh","Rohit","Rakesh","Ramesh","Rohit"]
emps.remove("Ramesh")
print(emps)
print(emps.index("Rohit"))
#remove second occurrence of Rohit
emps1=set(emps)
print(emps1)

for i in emps1:
    print(i)
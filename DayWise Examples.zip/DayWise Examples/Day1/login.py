username=input("Enter your username:")
password=input("Enter your password:")
if username=="admin" and password=="admin123":
    print("Login successful!")
else:
    print("Login failed!")

def greet_user(name):
    print("Hello, welcome to the !",name)   

greet_user("John")
def square(num):
    return num*num

result=square(5)
print("The square of 5 is:",result)
import os

db_host = os.environ.get('DB_HOST', 'localhost')
db_port = os.environ.get('DB_PORT', '5432')

print(f"Database Host: {db_host}")
print(f"Database Port: {db_port}")

os.environ['DB_HOST'] = "new_host"
print(f"Updated Database Host: {os.environ['DB_HOST']}")

# db_password = os.environ.get('DB_PASSWORD')
db_password = os.environ['DB_PASSWORD'] if 'DB_PASSWORD' in os.environ else None
print(f"Database Password: {db_password if db_password else 'Not Set'}")
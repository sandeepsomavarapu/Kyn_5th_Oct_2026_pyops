import os  # importing entire module
from pathlib import Path
import shutil

# file_path=os.path.join("var","log","app.log")
# print(os.path.exists(file_path))

# path=Path("var/log/app.log")
# print(path.exists())

# shutil.copy("new_name.txt","new_name_copy.txt")

# shutil.move("new_name_copy.txt","new_name_moved.txt")
# os.mkdir("new_folder")
#shutil.rmtree("new_folder")  # remove folder and its contents
shutil.make_archive("new_folder", "zip","new_folder")  # create a zip file from folder
shutil.unpack_archive("new_folder.zip", "extracted_folder")  # extract a zip file to a folder









# print(os.getcwd())
# # os.remove("test.txt")
# print(os.listdir())
# os.mkdir("new_folder")
# os.removedirs("new_folder")
# open("old_name.txt","w").write("This is a test file.")
# os.rename("old_name.txt","new_name.txt")

# import subprocess
# result=subprocess.run(["python", "moduledemo.py"])

# print("The output of the module demo is:",result)

import subprocess
import time

# Use PowerShell's Start-Sleep command on Windows
process = subprocess.Popen(["powershell", "-Command", "Start-Sleep -Seconds 5"])

print("The background process is running...")

while process.poll() is None:
    print("Still waiting...")
    time.sleep(1)

print(f"Finished with exit code: {process.returncode}")
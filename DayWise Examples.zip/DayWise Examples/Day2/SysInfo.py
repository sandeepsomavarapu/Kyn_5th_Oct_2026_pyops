import platform
import psutil



#1.cpu monitoring
print(psutil.cpu_percent(interval=1))
#2.Ram monitoring
ram = psutil.virtual_memory()
total_ram = ram.total / (1024 ** 3)  # Convert bytes to GB
used_ram = ram.used / (1024 ** 3)    # Convert bytes to GB

print(f"Total RAM: {total_ram:.2f} GB")
print(f"Used RAM: {used_ram:.2f} GB")

#3.disk monitoring
disk = psutil.disk_usage('/')
total_disk = disk.total / (1024 ** 3)  # Convert bytes to GB
used_disk = disk.used / (1024 ** 3)    # Convert bytes to GB

print(f"Total Disk: {total_disk:.2f} GB")
print(f"Used Disk: {used_disk:.2f} GB")

# print(f"System: {platform.system()}")
# print(f"Node: {platform.node()}")
# print(f"Release: {platform.release()}")
# print(f"Version: {platform.version()}")
# print(f"Machine: {platform.machine()}")
# print(f"Processor: {platform.processor()}")
# print(f"Architecture: {platform.architecture()}")
# print(f"Python Version: {platform.python_version()}")



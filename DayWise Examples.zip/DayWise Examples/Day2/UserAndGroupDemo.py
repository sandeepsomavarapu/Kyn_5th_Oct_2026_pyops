import win32net
import win32netcon
import win32security

def create_local_user(username, password):
    """Creates a standard local Windows user account."""
    user_info = {
        'name': username,
        'password': password,
        'priv': win32netcon.USER_PRIV_USER,  # Standard user privileges
        'comment': 'Sample user created via Python Subprocess/Admin script',
        'flags': win32netcon.UF_SCRIPT | win32netcon.UF_NORMAL_ACCOUNT
    }
    try:
        # Level 1 specifies user_info matching standard fields
        win32net.NetUserAdd(None, 1, user_info)
        print(f" Successfully created user: {username}")
    except Exception as e:
        print(f"❌ Failed to create user {username}: {e}")

def create_local_group(group_name):
    """Creates a local security group."""
    group_info = {
        'name': group_name,
        'comment': 'Sample group created via Python'
    }
    try:
        # Level 1 specifies group name and comment structures
        win32net.NetLocalGroupAdd(None, 1, group_info)
        print(f" Successfully created group: {group_name}")
    except Exception as e:
        print(f"❌ Failed to create group {group_name}: {e}")

def add_user_to_group(group_name, username):
    """Assigns a local user to an existing local group."""
    try:
        # Requires passing user details wrapped inside a dictionary list block
        win32net.NetLocalGroupAddMembers(None, group_name, 3, [{'domainandname': username}])
        print(f" Added user '{username}' to group '{group_name}'")
    except Exception as e:
        print(f"❌ Failed to add user to group: {e}")

def delete_user_and_group(username, group_name):
    """Cleans up and deletes the created user and group from Windows."""
    try:
        win32net.NetLocalGroupDel(None, group_name)
        print(f" Deleted group: {group_name}")
    except Exception as e:
         print(f"❌ Error deleting group: {e}")
         
    try:
        win32net.NetUserDel(None, username)
        print(f" Deleted user: {username}")
    except Exception as e:
        print(f"❌ Error deleting user: {e}")

# --- Execution ---
if __name__ == "__main__":
    # Test credentials
    TEST_USER = "PythonTestUser"
    TEST_PASS = "SecurePass123!"
    TEST_GROUP = "PythonDevelopers"

    print("--- Starting Windows Administration Tasks ---")
    
    # 1. Create entities
    create_local_user(TEST_USER, TEST_PASS)
    create_local_group(TEST_GROUP)
    
    # 2. Assign membership
    add_user_to_group(TEST_GROUP, TEST_USER)
    
    # 3. Clean up (Uncomment the line below if you want to automatically delete them after testing)
    # delete_user_and_group(TEST_USER, TEST_GROUP)

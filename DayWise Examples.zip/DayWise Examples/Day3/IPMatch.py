import re

sample_log="User admin failed to login from IP  192.168.1.1 at 10:30 Am with status 500"

ip_pattern = r'\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b'

status_pattern=r'status (\d{3})'
status_match = re.search(status_pattern, sample_log)
if status_match:
    status_code = status_match.group(1)
    print(f"Status Code: {status_code}")

ip_match = re.search(ip_pattern, sample_log)
if ip_match:
    ip_address = ip_match.group()
    print(f"IP Address: {ip_address}")

log_line = "2023-10-01 12:00:00,000 - INFO - Application started"
log_line1 = "2023-10-01 12:05:00,000 - ERROR - Database connection failed"

log_entries = [log_line, log_line1]

parts=log_line1.split(" - ")

print(parts)
print("Timestamp:", parts[0])
print("Level:", parts[1])
print("Message:", parts[2])
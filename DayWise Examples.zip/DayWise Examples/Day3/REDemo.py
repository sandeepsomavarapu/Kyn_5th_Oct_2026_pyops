import re

pattern = re.compile("ab")
matcher=pattern.finditer("ababcab")

for match in matcher:
    print(f"Found match at position {match.start()}-{match.end()}: {match.group()}")

import re


matcher=re.finditer("\\W","ca7b @ka9Z")

for match in matcher:
    print(f"Found match at position {match.start()}: {match.group()}")

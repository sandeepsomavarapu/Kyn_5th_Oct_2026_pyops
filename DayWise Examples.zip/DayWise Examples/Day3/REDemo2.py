import re


matcher=re.finditer("a{1,3}","abaabaaab")

for match in matcher:
    print(f"Found match at position {match.start()}: {match.group()}")

import re

matcher = re.search("ac$", "ababcab")
if matcher:
    print("target string found matches ")
else:
    print("target string does not exactly match the pattern")    




# matcher = re.fullmatch("ababcab", "ababcab")
# if matcher:
#     print("target string exactly matches the pattern")
# else:
#     print("target string does not exactly match the pattern")    



# matcher = re.match("ba", "ababcab")
# if matcher:
#     print("target string starts with ba")
# else:
#     print("target string does not start with ba")    
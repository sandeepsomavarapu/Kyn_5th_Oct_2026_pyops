import socket

domain="www.google.com"
ip = socket.gethostbyname(domain)
print(f"IP address of {domain}: {ip}")

hostname = socket.gethostname()
print(f"Hostname: {hostname}")
ip_local=socket.gethostbyname(hostname)
print(f"Local IP address: {ip_local}")

hostname_local = socket.gethostbyaddr(ip_local)
print(f"Local hostname: {hostname_local[0]}")
socket_info = socket.getaddrinfo(domain, 80)
print(f"Socket info for {domain}: {socket_info}")

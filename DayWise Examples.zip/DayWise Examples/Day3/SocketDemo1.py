import socket

# Create a TCP socket
server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)


# Bind to localhost on port 8080
server_socket.bind(('127.0.0.1', 8080))
server_socket.listen(1)
print("Server listening on 127.0.0.1:8080...")

# Accept incoming client connection
client_socket, address = server_socket.accept()
print(f"Connected to client at: {address}")

# Send a greeting message
client_socket.sendall(b"Hello from Python Network Server!")
client_socket.close()
server_socket.close()
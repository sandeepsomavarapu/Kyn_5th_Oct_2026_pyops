import socket

def test_port_connectivity(host, port, timeout=2):
    # Create socket object
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.settimeout(timeout) # Don't hang forever
    result = sock.connect_ex((host, port))
    sock.close()
    
    # connect_ex returns 0 if connection was successful
    if result == 0:
        return True
    else:
        return False

# Test Google's Web Server (Port 80)
is_open = test_port_connectivity("google.com", 80)
print(f"Google.com Port 80 Open: {is_open}")
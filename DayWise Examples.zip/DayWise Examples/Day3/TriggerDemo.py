import re
from collections import Counter

# Simulated raw log file contents
raw_logs = """
2026-10-07 10:00:01 INFO User john logged in
2026-10-07 10:00:05 ERROR Database Connection Failed from 192.168.1.10
2026-10-07 10:00:10 WARNING Disk space low
2026-10-07 10:00:15 ERROR Database Connection Failed from 192.168.1.12
2026-10-07 10:00:20 ERROR Unauthorized Access Attempt from 10.0.0.5
"""

def parse_error_logs(log_data):
    print("=== ERROR LOG PARSER REPORT ===")
    
    # Regex to capture timestamp, error message, and IP address
    error_pattern = r'(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}) ERROR (.*) from (\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})'
    
    matches = re.findall(error_pattern, log_data)
    
    print(f"Total Errors Found: {len(matches)}\n")
    
    for time, msg, ip in matches:
        print(f" [ALERT] Time: {time} | Issue: {msg} | Source IP: {ip}")

parse_error_logs(raw_logs)
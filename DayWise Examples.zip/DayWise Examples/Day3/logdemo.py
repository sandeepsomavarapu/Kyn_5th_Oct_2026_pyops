import logging

logging.basicConfig(level=logging.INFO,format='%(asctime)s - %(levelname)s - %(message)s')

def process_log_entry(log_message):
    if "CRITICAL" in log_message or "500" in log_message:
        logging.critical(log_message)

process_log_entry("2023-10-01 12:00:00,000 - INFO - Application started")
process_log_entry("2023-10-01 12:05:00,000 - ERROR - Database connection failed  status 500")
process_log_entry("2023-10-01 12:10:00,000 - CRITICAL - Server is down")
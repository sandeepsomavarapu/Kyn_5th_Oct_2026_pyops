import csv
import psutil
from datetime import datetime

def generate_health_csv(filename="server_health_report.csv"):

    headers=["TimeStamp","CPU_Usage","RAM_Usage","Disk_Usage","Status"]

    cpu=psutil.cpu_percent(interval=1)
    ram=psutil.virtual_memory().percent
    disk=psutil.disk_usage("/").percent
    status="CRITICAL" if (cpu>80 or ram>80 or disk>30) else "HEALTHY"
    timestamp=datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    with open(filename,mode='a',newline='')as file:
        writer=csv.writer(file) 
        if file.tell()==0:
            writer.writerow(headers)
        writer.writerow([timestamp,cpu,ram,disk,status])
    print("CSV Reported Successfully")            

generate_health_csv()    
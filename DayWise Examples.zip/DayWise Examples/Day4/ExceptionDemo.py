
try:
    a=int(input("Enter first number for division"))
    b=int(input("Enter second number for division"))
    result=a/b
    print("Division of two numbers ",result)
    list=[1,2,3,4]
    print(list[2])
    list.add(10)
    print(list)
except ZeroDivisionError:
    print("cannot devide by zero")
except ValueError:
    print("please enter only numbers")    
except IndexError:
    print("you are trying to access invalid index")    
except BaseException as be:
    print("Some Other Exception",be.__class__)
else:
    print("executes only when there is no error")    
finally:
    print("cleanup code will execute always")    
    
print("10000 lines of code")
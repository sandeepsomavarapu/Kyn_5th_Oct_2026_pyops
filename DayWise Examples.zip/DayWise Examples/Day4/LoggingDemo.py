import logging 

logging.basicConfig(
    filename="app_logs.log",
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s"
                    )
def safe_file_cleanup(file_path):
    try:
        logging.info(f"Intiating reading the file{file_path}")
        with open(file_path,'r') as file:
            data=file.read()
            print("file processed sucessfully")
    except FileNotFoundError as fe :
        logging.error(f"Target file is missing {file_path}")    
        print("target file is not found ")
    except PermissionError as pe:
        logging.critical(f"Access denied for the file{file}")  
        print("Insufficient Previliage")  
    finally:
        logging.info("file cleanup is completed")    
safe_file_cleanup("dummy.json")        
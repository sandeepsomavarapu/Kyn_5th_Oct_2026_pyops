username=input("enter your username")
password=input("enter your password")

if username=="admin" and password=="admin123":
    print("LOGIN SUCCESS")
else:
    raise ZeroDivisionError("Invalid credentials...")    